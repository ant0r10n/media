<?php
	$dbServer = '192.168.1.100:8889';
	$dbUsername = 'jotform';
	$dbPassword = 'xp98jk';
	$dbDatabase = 'mymedia';

	$adminConfig = array(
		'adminUsername' => "admin",
		'adminPassword' => "e90fb687478488c555c053841d90cb93",
		'notifyAdminNewMembers' => "0",
		'defaultSignUp' => "1",
		'anonymousGroup' => "anonymous",
		'anonymousMember' => "guest",
		'groupsPerPage' => "10",
		'membersPerPage' => "10",
		'recordsPerPage' => "10",
		'custom1' => "Full Name",
		'custom2' => "Address",
		'custom3' => "City",
		'custom4' => "State",
		'MySQLDateFormat' => "%m/%d/%Y",
		'PHPDateFormat' => "n/j/Y",
		'PHPDateTimeFormat' => "m/d/Y, h:i a",
		'senderName' => "Membership management",
		'senderEmail' => "anthony@0r10n.com",
		'approvalSubject' => "Your membership is now approved",
		'approvalMessage' => "Dear member,\n\nYour membership is now approved by the admin. You can log in to your account here:\nhttp://192.168.1.100:8888/media/mymedia\n\nRegards,\nAdmin"
	);